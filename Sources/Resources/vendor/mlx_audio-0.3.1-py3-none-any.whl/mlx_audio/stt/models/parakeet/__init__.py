from .parakeet import Model, ModelConfig
